//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2016
// Software Developers @ Learun 2016
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// Base_Supplies
    /// <author>
    ///		<name>MartyZane</name>
    ///		<date>2016.06.11 08:13</date>
    /// </author>
    /// </summary>
    public class Base_SuppliesBll : RepositoryFactory<Base_Supplies>
    {
    }
}