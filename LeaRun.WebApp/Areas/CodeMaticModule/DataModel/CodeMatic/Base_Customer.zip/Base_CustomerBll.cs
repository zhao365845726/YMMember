//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2016
// Software Developers @ Learun 2016
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// Base_Customer
    /// <author>
    ///		<name>MartyZane</name>
    ///		<date>2016.06.29 21:41</date>
    /// </author>
    /// </summary>
    public class Base_CustomerBll : RepositoryFactory<Base_Customer>
    {
    }
}